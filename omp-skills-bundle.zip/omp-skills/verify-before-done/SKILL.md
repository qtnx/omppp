---
name: verify-before-done
description: MANDATORY before claiming any coding task done, complete, fixed, implemented, passing, or ready. Use EVERY TIME you finish a bug fix, feature, refactor, endpoint, CLI/binary, frontend, mobile, or desktop change — and especially the moment you catch yourself about to offer only unit tests or a pre-existing smoke script as final proof. Also use whenever the environment seems to be MISSING something (no docker, no database, no credentials, no network, no runtime, no run instructions) — this skill contains the self-rescue ladder; never conclude "cannot verify" or fall back to unit-tests-only without running it. Contains concrete verification playbooks for Node.js/Go/Rust/Python backends, monorepos, microservices, CLIs, frontend via the browser tool, mobile, desktop, plus tmux driving, temporary instrumentation with mandatory restore, and the evidence format a done-claim must include.
---

# Verify Before Done

You are the engineer in charge. Before you say "done", you personally watch the thing work — the way its real user or caller will use it. Unit tests and pre-existing smoke scripts are rung-1 evidence: necessary, NEVER sufficient. If your final proof was going to be "tests pass" or "smoke script ran", that is the signal you have not verified yet. Run the playbook below. If the environment is missing pieces, that is not an excuse — run SELF-RESCUE (below) before lowering any claim.

Every claim ends in one of exactly two states:
- **VERIFIED** — you executed the real entry point, observed output + state + one failure path, and can paste the evidence block.
- **NOT VERIFIED** — you say so, name the gap, and hand the user a one-command harness to close it.
There is no third state. "Should work", "boots fine", "build is clean" are banned vocabulary.

---

## Step 1 — Classify in 10 seconds

| What changed | Real entry point | Required proof |
|---|---|---|
| Pure logic only | direct invocation | rung 2: fresh REPL/driver run |
| Routing / middleware / wiring / config | the running app's surface | rung 3: real request/invocation |
| Anything persisted / side effects | app surface + the store | rungs 3+4: request AND state query |
| UI | the rendered app | rung 3: browser-driven user flow |

Then jump to the matching platform playbook. In ALL cases, additionally run ONE failure path and fill the evidence block at the end.

---

## Step 2 — Universal sequence (all platforms)

1. **Discover the repo's own harness first**: package.json `scripts` / Makefile / justfile / compose files / `.env.example` / CI workflows / README. A CI workflow is a working recipe written by the team — copy its steps before inventing your own.
2. **Build the REAL artifact** — the thing that ships: `dist/` bundle, compiled binary, packed tarball, image. "Compiles in dev mode" is not the artifact.
3. **Run the artifact** and drive it through the real entry point.
4. **Assert three things**: the output (specific fields, not "got 200"), the state (query the store directly), one failure path (bad input → the DESIGNED error, store unchanged).
5. **Restore the world**: kill processes, remove temp instrumentation (see below), delete scratch files that aren't part of the deliverable harness.
6. **Write the evidence block** (format at the bottom) into your final answer.

---

## Technique — temporary instrumentation (legal, with mandatory restore)

Editing the code to make it verifiable is allowed and often the professional move:
- inject a mock at an unreachable external boundary (payment gateway, third-party API);
- force a feature flag / config branch on;
- add a temporary debug log at the suspicious line;
- shorten a timer/cron interval so a slow path runs now;
- relax a guard to reach a deep state you must test.

Rules that make it safe:
1. Tag EVERY temp edit with a marker comment on the same line: `// VERIFY-TEMP` (or `# VERIFY-TEMP`).
2. Keep a running list of file:line as you add them.
3. After verification, remove all of them and PROVE it: `grep -rn "VERIFY-TEMP" .` must print nothing before you yield.
4. Temp instrumentation never ships: the delivered change must contain only intended edits.

---

## Technique — driving live processes with tmux

For servers, watch modes, REPLs, TUIs, anything interactive:

```bash
tmux new-session -d -s vfy 'npm run dev 2>&1 | tee /tmp/vfy.log'
# readiness by POLLING, never blind sleep:
for i in $(seq 1 60); do curl -sf localhost:3000/health >/dev/null && break; sleep 1; done
tmux send-keys -t vfy 'some interactive input' Enter   # drive TUIs/REPLs
tmux capture-pane -t vfy -p                            # read the screen for assertions
tmux kill-session -t vfy                               # teardown, always
```

No tmux → `nohup <cmd> > /tmp/vfy.log 2>&1 & echo $! > /tmp/vfy.pid`, poll the log/port, `kill $(cat /tmp/vfy.pid)` at teardown. If the process never becomes ready, print the log and fix boot BEFORE testing anything. After ANY code edit, kill and re-boot before re-testing — a stale process means you are verifying old code.

---

## Backend — Node.js / TypeScript

1. Build real, run real: `npm run build`, then run the BUILT output (`node dist/server.js`) at least once — ts-node/dev mode hides ESM/CJS, path-alias, and env bugs that only exist in the artifact.
2. Deps up: `docker compose up -d postgres redis`, wait with `pg_isready -h localhost` (poll), migrate (`npx prisma migrate deploy` / repo's migrate script), seed — including a login-able user.
3. Boot in tmux/nohup, logs to file, poll `/health`.
4. Authenticate like a real client: `TOK=$(curl -s -X POST :3000/auth/login -d '{"email":"seed@x.y","password":"seed"}' | jq -r .token)` — or mint with the app's OWN jwt util + dev secret. NEVER disable auth middleware; a bypassed middleware is an untested middleware.
5. Real request, field-level asserts:
   ```bash
   curl -s -X POST :3000/users -H "Authorization: Bearer $TOK" -d '{"email":"a@b.c"}' | jq -e '.id and .email=="a@b.c"'
   ```
6. Rung 4 — query the store DIRECTLY:
   ```bash
   docker compose exec -T postgres psql -U app -d app -c "SELECT email,status FROM users WHERE email='a@b.c'"
   ```
   Assert the new rows AND that unrelated counts didn't move (no accidental writes), AND related tables (audit, counters, joins).
7. Failure paths ×2: invalid payload → designed 422 + DB unchanged (assert the count!); missing token → 401.

## Backend — Go

1. `go vet ./...`; build the binary and run IT: `go build -o /tmp/app ./cmd/server && /tmp/app`. Concurrency-touching change → `go test -race ./pkg/...` and boot a `-race` build for the manual probe.
2. Same DB/curl/psql flow as above. gRPC service: `grpcurl -plaintext :9090 list`, then `grpcurl -plaintext -d '{"id":"u1"}' :9090 pkg.UserService/Get` — assert the response message AND the DB row.
3. Failure path: send a request violating validation; a panic or bare 500 on bad input is a bug, not a pass.

## Backend — Rust

1. `cargo clippy -- -D warnings`; `cargo build` and run the target binary. Changed anything under `#[cfg(feature=...)]` → build the affected feature combos.
2. Same entry-point + store assertions. For async servers, verify one failing request doesn't take the runtime down.

## Backend — Python

Run under the app's own interpreter/venv; boot with the repo's entry (`uvicorn app.main:app`, `python -m app`, gunicorn config); identical curl → psql flow.

## Monorepo

1. Compute the affected graph, not just the edited package: `turbo run build test --filter=...{changed}`, `nx affected -t build,test`, `go build ./...`, `cargo build --workspace`.
2. Changed a shared lib → verify THROUGH a real consumer: rebuild the lib, then run one dependent app's real flow against it. Workspace symlinks + stale `dist/` lie constantly; rebuild before trusting.
3. The evidence block names which packages were rebuilt and which consumer app was exercised.

## Microservices

Fake verification is most tempting here. Do this instead:
1. Map the flow by reading code/config: which service owns the endpoint, what it calls downstream, which broker topics it touches.
2. Stand up the minimal REAL set: service under test + its DB + direct dependencies (`docker compose up -d svc-a svc-a-db nats`).
3. Downstream you genuinely cannot run → temporary in-code mock at the client boundary (VERIFY-TEMP) or a stub container; the claim must name the stub.
4. Invoke through the same path a real caller uses — through the gateway if one exists, not straight into the pod's private port (gateway routing/auth is part of the change surface).
5. Async flows: publish the REAL event (`nats pub orders.created '{"id":"o1"}'`, `kafka-console-producer`), then poll the consumer's store for the resulting state with a timeout; subscribe to output topics BEFORE triggering so you catch emitted events.
6. Assert per-service state: each service's own DB, plus the events emitted.
7. Changed a message/API shape → check both sides: current consumer against new producer (or explicitly report the compatibility gap).

## CLI / tool / binary

`--help` runs and `--version` prints is NOT verification.
1. Build the distributable and install it the way a user would, in a clean location: `npm pack` → `npm i -g ./pkg-1.0.0.tgz --prefix /tmp/cli-test`; `go build -o /tmp/bin/tool`; `cargo build --release`; `pipx install .`. Running from source hides packaging bugs (missing `files` entries, shebangs, asset paths).
2. Run the INSTALLED artifact from a DIFFERENT working directory, on realistic inputs. Assert stdout content, exit code, and produced files by CONTENT (`diff expected.out actual.out`), not existence.
3. Failure paths: unknown flag / missing file / malformed input → the designed message on stderr + non-zero exit. Tool claims atomic writes → kill it mid-write and confirm no corrupt output remains.
4. Interactive prompts: drive via tmux `send-keys`, `printf 'y\n' | tool`, or `expect`.

## Frontend (browser tool available — use it)

1. Build the REAL bundle and serve IT: `npm run build && npx vite preview` (or `npx serve dist`). Dev server masks minification, env-substitution, and base-path bugs. Dev-only task → dev server acceptable, but the claim must say which one you tested.
2. Need a backend? Boot the real API per the backend recipe (or the repo's designated mock server) — and name which in the claim.
3. Drive the ACTUAL user flow with the browser tool: navigate → click → type into the real form → submit. Not a screenshot of the landing page.
4. Assert: the on-screen result (specific text/element), AND the browser console is free of new errors — a rendered page with a red console is a FAIL.
5. Close the loop on persistence: after the UI flow, verify the round trip — reload and see the data, or hit the API/DB directly. Optimistic UI is not proof.
6. Failure path: submit invalid input → designed validation UI appears, no unhandled promise rejection, no error toast from a 500.
7. No browser tool in this environment → verify component + API rungs, then RAISE with a ready-to-run Playwright script for the user.

## Mobile app

Be honest about the device boundary:
1. Verify everything below it for real: business logic at rung 2, the API it calls at rungs 3+4.
2. Compile for the target if the toolchain exists: `./gradlew assembleDebug`, `xcodebuild -scheme App build`, `flutter analyze && flutter test`. React Native/Expo/Flutter with a web target and UI-logic changes → build the web target and drive it with the browser tool.
3. Emulator available → use it fully: boot, `adb install app-debug.apk` / `xcrun simctl install booted App.app`, drive the flow (`adb shell input tap/text`, maestro), capture screenshots as evidence.
4. No device/emulator → RAISE: mark device-side NOT VERIFIED and hand the user a numbered manual test script (exact taps + expected observation per screen).

## Desktop app (Electron / Tauri / native)

1. Change touches packaging or the main process → build the real package once (`npm run make`, `cargo tauri build`).
2. Headless box → `xvfb-run ./app` and drive it: Electron via `--remote-debugging-port=9222` + the browser tool/CDP, or Playwright's Electron driver; screenshot for evidence; assert logs for main-process/IPC behavior.
3. Renderer-only change and the app supports web mode → browser tool against the renderer.
4. No display possible → RAISE with the manual script, same as mobile.

---

## By change type

- **BUG FIX** — reproduce FIRST on the real entry point (the same curl/click/command the reporter would use); apply the fix; re-run the SAME reproduction. Evidence = broken output BEFORE and fixed output AFTER, both pasted. Then failure path + regression test.
- **FEATURE** — one full user path end-to-end on the real surface, state asserted, two failure paths (bad input, bad auth).
- **REFACTOR** — golden-output diffing: pick 2–3 representative real flows through the refactored code, capture their outputs BEFORE the refactor, re-run AFTER, compare field-by-field. Identical or explain every diff.
- **PERF** — the SAME measurement command before and after, on the same workload; paste both numbers.

---

## SELF-RESCUE — missing tooling, env, services, credentials, or harness

Never stop at "the environment doesn't have X". Never silently downgrade to unit tests either. For EVERY missing piece, run the six moves IN ORDER and stop at the first that works:

1. **SEARCH** — the repo probably solved this already. Look in: CI workflows (they run in a bare environment exactly like yours), test setup/teardown files (testcontainers configs, sqlite fallbacks, fixture servers), `scripts/`, Dockerfiles, `.tool-versions`/`.nvmrc`, existing `__mocks__`/fixtures directories. Copy the team's own answer before inventing yours.
2. **PROVISION** — obtain the missing thing:
   - toolchain: the version manager the repo pins (nvm/mise/asdf via `.nvmrc`/`.tool-versions`, `go.mod` toolchain line, `corepack enable` for pnpm/yarn), else package-manager install;
   - service: `docker run` (or podman) a single container; no container runtime → native install (`apt-get install postgresql redis-server`) → embedded/file-mode engines;
   - after TWO distinct failed provisioning attempts for the same thing, move to the next move — do not fight the environment forever.
3. **SUBSTITUTE** — a lower-realism stand-in is legal only when its differences do not intersect the change under test, and you VERIFY that claim instead of assuming it:
   - sqlite for postgres ONLY after checking the touched queries for dialect features: `grep -rnE "jsonb|ON CONFLICT|ILIKE|FOR UPDATE|::|RETURNING" <touched sql/orm files>` comes back clean;
   - miniredis / in-memory broker for cache/queue when the change is not about delivery or eviction semantics;
   - `vite preview` / static serve instead of the production CDN.
   Every substitution is DECLARED in the evidence block.
4. **SHRINK THE BOUNDARY** — when something must be faked, fake the SMALLEST unreachable thing, as far from your change as possible, so the maximum real code still executes. Fake the Stripe HTTP client, not the whole billing service; fake the SMTP transport, not the notification module. A 10-line localhost stub server (node/python http server returning the documented response shapes, base URL pointed at it via env) beats an in-code mock: your real HTTP client, serialization, retries, and error handling still run. Whatever you stub: CAPTURE what your code sent to it and assert the outbound payload — the stub verifies your side of the contract too.
5. **INSTRUMENT** — edit the code itself to make verification possible (VERIFY-TEMP rules above): inject the fake at the client boundary, force the flag, shortcut into the deep state, shrink the timer, pin the clock/seed. Restore everything and prove restoration before yield.
6. **RAISE** — only after moves 1–5: mark that slice NOT VERIFIED, deliver everything verified below the gap, and hand the user a ONE-COMMAND harness to close it (script + seed + expected output). Raising without having tried 1–5 is abandoning the task; raising after them is professional honesty.

### Situation ladders

- **MISSING RUNTIME / COMPILER** → repo-pinned version manager → package-manager install → run the toolchain inside a container mounting the workdir (`docker run --rm -v "$PWD":/w -w /w node:20 sh -c 'npm ci && npm run build'`) → RAISE with the exact install command.
- **MISSING DB / CACHE / BROKER** → repo compose service → single `docker run` → native install → embedded/file-mode engine with the dialect check from move 3 → driver-boundary fake (VERIFY-TEMP) that RECORDS every query/command it received, so you can assert your code's writes → RAISE.
- **MISSING CREDENTIALS / ENV VARS** → enumerate first: `grep -rn "process.env\|os.Getenv\|env::var\|os.environ"` + read `.env.example` and the config schema. Then classify EACH var:
  - (a) app-internal secret (JWT/session/encryption key) → GENERATE a dev value yourself; it only needs to exist and be self-consistent across the harness;
  - (b) local infra URL (DB, redis, broker) → point at the harness you stood up;
  - (c) third-party key (Stripe, OAuth client, S3) → NEVER invent one and let calls fail confusingly; stub that ONE boundary per move 4;
  - (d) behavior flag → set to the value the flow under test requires; record it as harness config, not a code change.
- **NO NETWORK / BLOCKED REGISTRY** → offline installs from what exists (`npm ci --offline`, present `node_modules`, `go mod vendor` dir, `pip install --no-index --find-links`) → verify the subset that doesn't need the missing dependency → RAISE with the exact command the user runs on a networked machine.
- **UNREACHABLE EXTERNAL API** → repo's own recordings/fixtures (nock, VCR, httpmock) → localhost stub server per move 4 → in-code client mock (VERIFY-TEMP) → RAISE. In all cases assert the OUTBOUND request your code produced, not just that the flow completed.
- **UNREACHABLE STATE** (flow needs an order already "shipped", a user mid-onboarding, retry attempt 3) → drive the real flow to that state (best) → direct-insert PREREQUISITE state only (never the data your flow is supposed to write) → VERIFY-TEMP shortcut into the state → probe the behavior from that state forward, then restore.
- **UNDOCUMENTED REPO** (no README, no scripts) → reverse-engineer the entry point: manifest `main`/`bin`, Dockerfile `CMD`/`ENTRYPOINT`, CI job commands, framework conventions (`manage.py`, `cmd/`, `src/main.rs`, `artisan`). Whatever runbook you reconstruct goes into the handoff so nobody repeats the archaeology.
- **NONDETERMINISM** (time, cron, random, concurrency) → control the variable: pin the clock/seed via env or VERIFY-TEMP; shrink the interval; call the job entry directly. Concurrency claims → fire N parallel REAL requests (`seq 20 | xargs -P20 -I{} curl -s -X POST ...`) and assert invariants on the store afterward (exact counts, no double-spend).

### Iron rules
- No silent skips: every missing piece either got solved by moves 1–5 or appears under NOT VERIFIED. There is no third outcome.
- No undeclared substitutions: each step down the realism ladder is named in the evidence block.
- Effort follows risk: an L1 pure-logic fix does not justify an hour of docker archaeology — rung 2 proof and move on; a payment/migration flow justifies the full ladder.
- Two failed attempts per move, then descend the ladder. The ladder exists so you keep moving.

---

## Evidence block — paste this in the final answer, filled

```
VERIFIED — <task>, rung <N>
build:   <command> → exit 0
run:     <command / tmux session> → ready in <s>s, log: <path>
probe:   <exact request/click/command> → <observed output, specific fields>
state:   <exact query> → <observed rows/values; unrelated counts unchanged>
failure: <bad input> → <designed error observed>, state unchanged
substitutions/stubs: <each declared, or "none — full realism">
restore: VERIFY-TEMP grep = 0 hits; processes killed; scratch removed
NOT VERIFIED: <list or "none"> — <gap>; user closes it with: <one command>
```

## Pre-yield checklist
1. Did I execute the change through its REAL entry point in this session (not just tests)?
2. Did I run the BUILT artifact at least once, not only dev mode?
3. Did I assert state in the store directly, not just the response?
4. Did I run at least one failure path and check state stayed clean?
5. Did I re-boot after my last edit before the final probe?
6. Did every missing-env gap go through SELF-RESCUE moves 1–6 (no silent downgrade to unit tests)?
7. Is every substitution and stub declared in the evidence block?
8. Is `grep -rn "VERIFY-TEMP"` empty and every background process dead?
9. Is every remaining gap listed under NOT VERIFIED with a one-command harness for the user?
Any "no" → you are not done. Go back to the matching playbook.
